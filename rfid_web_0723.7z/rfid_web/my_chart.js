


var running = 0;
var time = 0;
// Live Subs Charts
var ctx_live = document.getElementById("myChart");

var liveChart = new Chart(ctx_live, {
    type: 'line',
    data: {
    labels: Array(1500).fill(''),
  datasets: [{
    tp: Array(1500).fill(null), // Hiram : Add for timestamp
    data: Array(1500).fill(null),
    pointRadius: 1, 
    fill: false,
    lineTension: 0,
    borderWidth: 1,
    borderColor:'#00c0ef',
    label: 'RSSI MAX',
  }]
  },
  options: {
    onClick: function(event){
      var activePoints = this.getElementAtEvent(event);
      if (activePoints.length > 0) 
      {
        var clickedDatasetIndex = activePoints[0]._datasetIndex;
        var clickedElementindex = activePoints[0]._index;
        var label = this.data.labels[clickedElementindex];
        var value = this.data.datasets[clickedDatasetIndex].data[clickedElementindex];     
        var tp = this.data.datasets[clickedDatasetIndex].tp[clickedElementindex];     
        alert("Clicked: " + label + " --- " + tp + ":" + value);
      }
    },
    tooltips: {
         enabled: true
    },  
  responsive: false,
  maintainAspectRatio: false,
  legend: {
  display: true
  },
  scales: {
  yAxes: [{
    display: true,
    position: 'right',
    ticks: {
      //beginAtZero:false,
      max: -25,
      min: -70,
      stepSize: 5
    }
  },{
    display: true,
    position: 'left',
    ticks: {
      //beginAtZero:false,
      max: -25,
      min: -70,
      stepSize: 5
    }
  }],
  xAxes: [{
  display: true,
  distribution: 'series',
    ticks: 
    {
      beginAtZero:true,
      stepSize: 5
    }
  }],
  }
  }
});

var chart_dir = 'r'; // r: chart from right / l: chart from left
var otp = 0;
//var doAjax = function() 



console.log( document.querySelector('#rssi_val'))




btn_start.onClick = function() {

  console.log("in doAjax");
  $.ajax({
    url: "/api/chart",
    success: function(result)
    {
      var currentValue = result;                                     
      var i=0;    

      if(running == 0){
        console.log("no drawing...");
        return;
      }
//      document.getElementById('messages').innerHTML = JSON.stringify(result);

      // Make fake data for empty object
      if(Object.entries(currentValue[0]).length == 0)//Object.entries查一下?
      {
	console.log("empty rssi");
	for(i=0;i<5;i++)
	{
          if(chart_dir == 'r')                                                                                                                                                              
          {                                                                                                                                                                                 
            liveChart.data.datasets[0].data.push(null);                                                                                                                                     
            liveChart.data.datasets[0].tp.push(null);                                                                                                                                       
          }                                                                                                                                                                                 
          else                                                                                                                                                                              
          {                                                                                                                                                                                 
            liveChart.data.datasets[0].data.unshift(null);                                                                                                                                  
            liveChart.data.datasets[0].tp.unshift(null);                                                                                                                                    
          }  

          if(liveChart.data.datasets[0].data.length > 1500 ) //5min                                                                                                                           
          {                                                                                                                                                                                   
            if(chart_dir == 'r')                                                                                                                                                              
            {                                                                                                                                                                                 
              liveChart.data.labels.shift();                                                                                                                                                  
              liveChart.data.datasets[0].data.shift();                                                                                                                                        
              liveChart.data.datasets[0].tp.shift();                                                                                                                                          
            }                                                                                                                                                                                 
            else                                                                                                                                                                              
            {                                                                                                                                                                                 
              liveChart.data.labels.pop();                                                                                                                                                    
              liveChart.data.datasets[0].data.pop();                                                                                                                                          
              liveChart.data.datasets[0].tp.pop();                                                                                                                                            
            }                                                                                                                                                                                 
          } 
        
	  if(chart_dir == 'r')                                                                                                                                                                
          {                                                                                                                                                                                   
            liveChart.data.labels.push(++time);                                                                                                                                               
          }                                                                                                                                                                                   
          else                                                                                                                                                                                
          {                                                                                                                                                                                   
            liveChart.data.labels.unshift(++time);                                                                                                                                            
          }                                                                                                                                                                                   
          liveChart.update();
        } // end of for
	return; // end of process                                                                                                                                               
      }


      i = 0; 
      while(Object.entries(currentValue[i]).length != 0)                                                           
      {                                                 
	console.log(currentValue[i].tp);                          
        if(currentValue[i].tp > otp)
        { 
        	if(chart_dir == 'r')
          	{                         
            		liveChart.data.datasets[0].data.push(currentValue[i].RSSI);
            		liveChart.data.datasets[0].tp.push(currentValue[i].tp);
          	}
          	else
          	{
            		liveChart.data.datasets[0].data.unshift(currentValue[i].RSSI);
            		liveChart.data.datasets[0].tp.unshift(currentValue[i].tp);
          	}
          	otp = currentValue[i].tp; 

	  	//------------ set gauge --------------------
	  	rssi_gauge.set(Math.abs(currentValue[i].RSSI));
	  	$("#msg_rssi_val").html(currentValue[i].RSSI); //綁網頁rssi直
    
	  	//-------------------------------------------
        }
        else
        {
          if(chart_dir == 'r')
          {                         
            liveChart.data.datasets[0].data.push(null);
            liveChart.data.datasets[0].tp.push(null);
          }
          else
          {
            liveChart.data.datasets[0].data.unshift(null);
            liveChart.data.datasets[0].tp.unshift(null);
          }
          currentValue[i].RSSI = null;
          currentValue[i].tp = null;
        } // end of else

              
        if(liveChart.data.datasets[0].data.length > 1500 ) //5min               
        {                                                                         
          if(chart_dir == 'r')
          {                         
            liveChart.data.labels.shift();                                        
            liveChart.data.datasets[0].data.shift(); 
            liveChart.data.datasets[0].tp.shift(); 
          }
          else
          {                             
            liveChart.data.labels.pop();                                        
            liveChart.data.datasets[0].data.pop();
            liveChart.data.datasets[0].tp.pop();
          }                              
        }


        if(chart_dir == 'r')
        {                         
          liveChart.data.labels.push(++time);
        }
        else
        {   
          liveChart.data.labels.unshift(++time);
        }   
        liveChart.update();
	i++;                                                       
      } // end of while                                                                           
    },
    complete: function () 
    {
      setTimeout(doAjax, 1000);
      //counter_inc();
    }
  
  });
 
};

