var ant_data = document.getElementById('getatn')
ant_data.onclick() = function(){
    var req = new XMLHttpRequest();
    req.open("get","/rfid_web/readercap.json");
    req.onload = function(){
        const json = JSON.parse(req.responseText)
        console.log(json)
    }
    req.send()
}